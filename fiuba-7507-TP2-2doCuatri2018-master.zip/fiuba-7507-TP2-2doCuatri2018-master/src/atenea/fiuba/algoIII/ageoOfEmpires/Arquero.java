package atenea.fiuba.algoIII.ageoOfEmpires;

public class Arquero {

    private final int _vidaMaxima;

    public Arquero(int vidaMaxima){
        _vidaMaxima = vidaMaxima;
    }

}
