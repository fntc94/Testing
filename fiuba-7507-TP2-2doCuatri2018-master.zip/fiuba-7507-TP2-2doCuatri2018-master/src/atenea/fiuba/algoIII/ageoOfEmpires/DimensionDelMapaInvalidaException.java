package atenea.fiuba.algoIII.ageoOfEmpires;

public class DimensionDelMapaInvalidaException extends RuntimeException {

    public DimensionDelMapaInvalidaException(String mensaje){
        super(mensaje);
    }
}
