package atenea.fiuba.algoIII.ageoOfEmpires;

public class Espadachin {

    private final int _vidaMaxima;

    public Espadachin(int vidaMaxima){
        _vidaMaxima = vidaMaxima;
    }

}
