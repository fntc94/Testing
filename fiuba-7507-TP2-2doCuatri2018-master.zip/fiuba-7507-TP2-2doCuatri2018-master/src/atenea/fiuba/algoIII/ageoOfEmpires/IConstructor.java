package atenea.fiuba.algoIII.ageoOfEmpires;

public interface IConstructor {

    boolean estaConstruyendo();
    void continuarConstruyendo();
}
