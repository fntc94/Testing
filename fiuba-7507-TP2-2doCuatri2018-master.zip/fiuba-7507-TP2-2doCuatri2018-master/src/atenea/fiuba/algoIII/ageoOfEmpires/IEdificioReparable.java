package atenea.fiuba.algoIII.ageoOfEmpires;

public interface IEdificioReparable {

    void recibirReparador(IEstadoReparador reparador);

}
