package atenea.fiuba.algoIII.ageoOfEmpires;

interface IEstadoAldeano extends IEstadoRecolectorOro, IEstadoConstructor, IEstadoReparador {

}
