package atenea.fiuba.algoIII.ageoOfEmpires;

public interface IEstadoArmaDeAsedio {

    boolean estaMontada();
    void atacar();
    void mover();

}
