package atenea.fiuba.algoIII.ageoOfEmpires;

public interface IEstadoConstructor {

    void iniciarConstruccion();
    void continuarConstruyendo();
    boolean estaConstruyendo();

}
