package atenea.fiuba.algoIII.ageoOfEmpires;

public interface IEstadoRecolectorOro {

    boolean estaRecolectandoOro();
    int recolectarOro();

}
