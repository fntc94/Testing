package atenea.fiuba.algoIII.ageoOfEmpires;

public interface IPosicionable {

    Posicion getPosicion();

}
