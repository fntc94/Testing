package atenea.fiuba.algoIII.ageoOfEmpires;

public interface IRecolectorOro {

    boolean estaRecolectandoOro();
    int recolectarOro();

}
