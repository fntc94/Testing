package atenea.fiuba.algoIII.ageoOfEmpires;

public class NoPuedeColocar2IPosicionablesEnLaMismaPosicionException extends RuntimeException{
}
