package atenea.fiuba.algoIII.ageoOfEmpires;

public class NoPuedeColocarPosicionablesFueraDelMapaException extends RuntimeException{
}
