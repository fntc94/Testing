package atenea.fiuba.algoIII.ageoOfEmpires;

public class NullEdificioReparable implements IEdificioReparable {

    @Override
    public void recibirReparador(IEstadoReparador reparador) {
        //hace nada.
    }
}
