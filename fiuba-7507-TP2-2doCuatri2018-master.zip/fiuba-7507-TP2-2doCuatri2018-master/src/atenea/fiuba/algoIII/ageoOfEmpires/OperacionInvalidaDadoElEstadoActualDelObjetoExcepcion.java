package atenea.fiuba.algoIII.ageoOfEmpires;

public class OperacionInvalidaDadoElEstadoActualDelObjetoExcepcion extends RuntimeException {

}
