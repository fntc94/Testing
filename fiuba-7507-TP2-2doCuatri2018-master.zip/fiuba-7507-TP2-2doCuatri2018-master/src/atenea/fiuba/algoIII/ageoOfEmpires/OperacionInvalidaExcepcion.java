package atenea.fiuba.algoIII.ageoOfEmpires;

public class OperacionInvalidaExcepcion extends RuntimeException {
}
